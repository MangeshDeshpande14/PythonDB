import mysql.connector as mycon

con = mycon.connect(host='bfonzxavkaj7sdtm9hpi-mysql.services.clever-cloud.com',user='ueeuvhal79mzkix6',password='r52jfCwGV4sIhPNLtTCa',database='bfonzxavkaj7sdtm9hpi')
curs = con.cursor()

try:
    auth = input('Enter author: ')
    pub = input('Enter publication: ')
    curs.execute('select * from books where author="%s" and publication="%s"' %(auth,pub))
    data = curs.fetchall()
    if data:
        print('Search results:')
        for i in data:
            print('')
            print('Book code: %s' %i[0])
            print('Book name: %s' %i[1])
            print('Category: %s' %i[2])
            print('Author: %s' %i[3])
            print('Publication: %s' %i[4])
            print('Edition: %s' %i[5])
            print('Price: %.2f' %i[6])
            print('Review: %s' %i[7])
    else:
        print('author-publication combination not found')
except Exception as e:
    print(e)

con.close()