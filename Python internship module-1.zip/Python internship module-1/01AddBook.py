import mysql.connector as mycon

con = mycon.connect(host='bfonzxavkaj7sdtm9hpi-mysql.services.clever-cloud.com',user='ueeuvhal79mzkix6',password='r52jfCwGV4sIhPNLtTCa',database='bfonzxavkaj7sdtm9hpi')
curs = con.cursor()

try:
    code = input('Enter book code: ')
    name = input('Enter book name: ')
    cat = input('Enter category (comedy, horror, biography, etc.): ')
    author = input('Enter author: ')
    pub = input('Enter publication: ')
    edition = input('Enter edition: ')
    price = float(input('Enter price: '))

    curs.execute('insert into books values("%s","%s","%s","%s","%s","%s",%.2f,default)' %(code,name,cat,author,pub,edition,price))
    con.commit()
    print('New book added!')
#except Exception as e:
    #print(e)
except:
    print('Error! Cannot add book')

con.close()