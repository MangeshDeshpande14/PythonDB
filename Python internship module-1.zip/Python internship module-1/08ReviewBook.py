import mysql.connector as mycon

con = mycon.connect(host='bfonzxavkaj7sdtm9hpi-mysql.services.clever-cloud.com',user='ueeuvhal79mzkix6',password='r52jfCwGV4sIhPNLtTCa',database='bfonzxavkaj7sdtm9hpi')
curs = con.cursor()

try:
    code = input('Enter book code: ')
    curs.execute('select * from books where bookcode="%s"' %code)
    data = curs.fetchone()
    if data:
        print('Book name: %s' %data[1])
        review = input('Write review for this book: ')
        curs.execute('update books set review="%s" where bookcode="%s"' %(review,code))
        con.commit()
        print('Review Submitted')
    else:
        print('Book not found')
except Exception as e:
    print(e)

con.close()