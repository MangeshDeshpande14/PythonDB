import mysql.connector as mycon

con = mycon.connect(host='bfonzxavkaj7sdtm9hpi-mysql.services.clever-cloud.com',user='ueeuvhal79mzkix6',password='r52jfCwGV4sIhPNLtTCa',database='bfonzxavkaj7sdtm9hpi')
curs = con.cursor()

try:
    code = input('Enter book code to search: ')
    curs.execute('select * from books where bookcode="%s"' %code)
    data = curs.fetchone()
    if data:
        print('Search Result:')
        print('')
        print('Book name: %s' %data[1])
        print('Category: %s' %data[2])
        print('Author: %s' %data[3])
        print('Publication: %s' %data[4])
        print('Edition: %s' %data[5])
        print('Price: %.2f' %data[6])
        print('Review: %s' %data[7])
    else:
        print('Book not found!')
except Exception as e:
    print(e)

con.close()